package useGin

func CollectRoutes() {

}
